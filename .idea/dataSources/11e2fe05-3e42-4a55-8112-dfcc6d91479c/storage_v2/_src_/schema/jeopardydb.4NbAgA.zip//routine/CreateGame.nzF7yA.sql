create
    definer = jbooker@localhost procedure CreateGame()
BEGIN
    INSERT INTO Games (DatePlayed, Status) VALUES (NOW(), 'Not Started');
END;

