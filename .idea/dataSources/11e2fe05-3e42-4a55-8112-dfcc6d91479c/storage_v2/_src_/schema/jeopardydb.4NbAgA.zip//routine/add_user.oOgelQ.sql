create
    definer = jbooker@localhost procedure add_user(IN new_username varchar(20), IN new_password varchar(64),
                                                   IN new_email varchar(255))
BEGIN
    DECLARE salt VARBINARY(8);
    SET salt = (SELECT make_salt(8));

    INSERT INTO Users (Username, PasswordHash, Salt, Email) 
    VALUES (new_username, SHA2(CONCAT(new_password, salt), 256), salt, new_email);
END;

