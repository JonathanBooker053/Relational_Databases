create
    definer = jbooker@localhost procedure FinishGame(IN gameID_ int)
BEGIN
    UPDATE Games SET Status = 'Pending' WHERE GameID = gameID_;
END;

