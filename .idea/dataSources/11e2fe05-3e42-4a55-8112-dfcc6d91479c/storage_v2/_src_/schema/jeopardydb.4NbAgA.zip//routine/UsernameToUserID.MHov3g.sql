create
    definer = jbooker@localhost function UsernameToUserID(username_ varchar(255)) returns int deterministic
BEGIN
    DECLARE userID INT;
    SELECT UserID INTO userID FROM Users WHERE Username = username_;
    RETURN userID;
END;

