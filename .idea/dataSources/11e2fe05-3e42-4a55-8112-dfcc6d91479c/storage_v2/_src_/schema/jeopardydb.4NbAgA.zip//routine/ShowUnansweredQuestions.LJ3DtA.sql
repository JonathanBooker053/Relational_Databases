create
    definer = jbooker@localhost procedure ShowUnansweredQuestions(IN gameID int, IN round_ varchar(255))
BEGIN
    SELECT Category, Value FROM Questions q
    JOIN GameQuestions gq ON q.QuestionID = gq.QuestionID
    WHERE gq.GameID = gameID AND q.Round = round AND q.QuestionID NOT IN (
    SELECT GameQuestionID FROM Answer
);
END;

