create
    definer = jbooker@localhost procedure AddPlayerToGame(IN gameID_ int, IN userID_ int)
BEGIN
    INSERT INTO GamePlayers (GameID, UserID) VALUES (gameID_, userID_);
END;

