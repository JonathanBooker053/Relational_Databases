create
    definer = jbooker@localhost procedure add_client(IN user_id int)
BEGIN
    IF NOT EXISTS (SELECT * FROM Client WHERE UserID = user_id) THEN
        INSERT INTO Client (UserID) VALUES (user_id);
    END IF;
END;

