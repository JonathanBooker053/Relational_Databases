create
    definer = jbooker@localhost function CorrectAnswerProportion(userID int) returns decimal(5, 2) deterministic
BEGIN
    DECLARE correctProportion DECIMAL(5, 2);

    -- Select the proportion of questions answered correctly by the specified user.
    SELECT (SELECT COUNT(*) FROM Answer a JOIN GamePlayers gp ON a.GamePlayerID = gp.GamePlayerID WHERE gp.UserID = userID AND a.IsCorrect = 1) / (SELECT COUNT(*) FROM Answer a JOIN GamePlayers gp ON a.GamePlayerID = gp.GamePlayerID WHERE gp.UserID = userID) INTO correctProportion;

    RETURN correctProportion;
END;

