create
    definer = jbooker@localhost function IsAdmin(userID_ int) returns tinyint(1) deterministic
BEGIN
    DECLARE isAdmin BOOLEAN;
    SELECT EXISTS(SELECT * FROM Admin WHERE UserID = userID_) INTO isAdmin;
    RETURN isAdmin;
END;

