create
    definer = jbooker@localhost procedure AddCategoryToGame(IN gameID_ int, IN category_ varchar(255), IN airDate_ date)
BEGIN
    INSERT INTO GameQuestions (GameID, QuestionID)
    SELECT gameID_, QuestionID
    FROM Questions
    WHERE Category = category_ AND AirDate = airDate_;
END;

