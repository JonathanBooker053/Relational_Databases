create
    definer = jbooker@localhost procedure ShowCategoriesFromRound(IN round_ varchar(255))
BEGIN
    SELECT DISTINCT Category FROM Questions WHERE Round = round_;
END;

