create
    definer = jbooker@localhost function GetWinnerUserID(gameID_ int) returns int deterministic
BEGIN
    DECLARE winnerID INT;
    SELECT gp.UserID INTO winnerID
    FROM GamePlayers gp
    JOIN (
        SELECT GamePlayerID, GetPlayerScore(GamePlayerID) AS Score
        FROM GamePlayers
        WHERE GameID = gameID_
    ) AS scores ON gp.GamePlayerID = scores.GamePlayerID
    ORDER BY scores.Score DESC
    LIMIT 1;
    RETURN winnerID;
END;

