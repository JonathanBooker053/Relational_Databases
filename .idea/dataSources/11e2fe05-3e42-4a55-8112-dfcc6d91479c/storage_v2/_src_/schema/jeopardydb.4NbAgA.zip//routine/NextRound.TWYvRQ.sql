create
    definer = jbooker@localhost procedure NextRound(IN gameID_ int, IN newStatus varchar(255))
BEGIN
    UPDATE Games SET Status = newStatus WHERE GameID = gameID_;
END;

