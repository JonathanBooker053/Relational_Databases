create
    definer = jbooker@localhost procedure AddAnswer(IN gamePlayerID_ int, IN gameQuestionID_ int, IN userAnswer_ text,
                                                    IN isCorrect_ tinyint, IN points__ int)
BEGIN
    INSERT INTO Answer (GamePlayerID, GameQuestionID, UserAnswer, IsCorrect, Points_) VALUES (gamePlayerID_, gameQuestionID_, userAnswer_, isCorrect_, points__);
END;

