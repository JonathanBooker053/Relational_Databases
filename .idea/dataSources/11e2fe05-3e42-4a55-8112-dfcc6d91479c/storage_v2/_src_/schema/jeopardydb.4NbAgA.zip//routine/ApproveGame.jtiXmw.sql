create
    definer = jbooker@localhost procedure ApproveGame(IN gameID_ int, IN adminUserID int)
BEGIN
    UPDATE Games
    SET Status = 'Pending', Admin = adminUserID
    WHERE GameID = gameID_ AND Status = 'Complete' AND Admin IS NOT NULL;
END;

