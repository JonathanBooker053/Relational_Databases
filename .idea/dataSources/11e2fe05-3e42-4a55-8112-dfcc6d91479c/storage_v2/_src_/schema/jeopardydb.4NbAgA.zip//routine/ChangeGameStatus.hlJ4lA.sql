create
    definer = jbooker@localhost procedure ChangeGameStatus(IN gameID_ int, IN newStatus varchar(255))
BEGIN
    UPDATE Games SET Status = newStatus WHERE GameID = gameID_;
END;

