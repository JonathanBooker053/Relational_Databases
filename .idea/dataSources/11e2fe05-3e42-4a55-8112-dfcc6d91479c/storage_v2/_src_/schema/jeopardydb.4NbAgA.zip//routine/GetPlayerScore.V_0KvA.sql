create
    definer = jbooker@localhost function GetPlayerScore(GamePlayerIDParam int) returns int deterministic
BEGIN
    DECLARE finalScore INT DEFAULT 0;
    -- Ensure the calculation only includes questions that have been answered (IsCorrect is not NULL)
    SELECT SUM(CASE WHEN a.IsCorrect = 1 THEN q.Value_ WHEN a.IsCorrect = 0 THEN -q.Value_ ELSE 0 END) INTO finalScore
    FROM Answer a
    JOIN GameQuestions gq ON a.GameQuestionID = gq.GameQuestionID
    JOIN Questions q ON gq.QuestionID = q.QuestionID
    WHERE a.GamePlayerID = GamePlayerIDParam;
    RETURN finalScore;
END;

