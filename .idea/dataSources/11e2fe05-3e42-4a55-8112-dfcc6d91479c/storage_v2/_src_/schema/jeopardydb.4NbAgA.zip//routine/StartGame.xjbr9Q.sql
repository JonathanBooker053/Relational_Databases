create
    definer = jbooker@localhost procedure StartGame(IN gameID_ int)
BEGIN
    UPDATE Games SET Status = 'Jeopardy!' WHERE GameID = gameID_;
END;

