create
    definer = jbooker@localhost function IsClient(userID_ int) returns tinyint(1) deterministic
BEGIN
    DECLARE isClient BOOLEAN;
    SELECT EXISTS(SELECT * FROM Client WHERE UserID = userID_) INTO isClient;
    RETURN isClient;
END;

