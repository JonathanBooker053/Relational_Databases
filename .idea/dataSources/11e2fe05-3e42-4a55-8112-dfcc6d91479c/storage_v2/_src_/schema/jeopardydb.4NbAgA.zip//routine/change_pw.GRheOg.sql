create
    definer = jbooker@localhost procedure change_pw(IN username_ varchar(20), IN new_password varchar(255))
BEGIN
    -- Generate a new salt of 8 characters
    DECLARE new_salt VARCHAR(8);
    SET new_salt = (SELECT make_salt(8));
    
    -- Update the user's password hash and salt in the database
    UPDATE Users SET Salt = new_salt, PasswordHash = SHA2(CONCAT(new_salt, new_password), 256)
    WHERE username = username_;
END;

