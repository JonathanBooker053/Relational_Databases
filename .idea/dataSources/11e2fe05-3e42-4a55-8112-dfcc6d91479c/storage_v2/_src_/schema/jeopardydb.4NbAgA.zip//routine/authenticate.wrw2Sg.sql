create
    definer = jbooker@localhost function authenticate(username_ varchar(20), password varchar(255)) returns tinyint
    deterministic
BEGIN
    DECLARE pass_hash BINARY(64);
    DECLARE stored_salt VARCHAR(8);
    DECLARE user_exists INT DEFAULT 0;

    SELECT COUNT(*) INTO user_exists FROM Users WHERE username = username_;

    IF user_exists = 0 THEN
        -- User does not exist
        RETURN 0;
    ELSE
        SELECT salt, pass_hash INTO stored_salt, pass_hash FROM Users WHERE username = username_ LIMIT 1;

        IF SHA2(CONCAT(stored_salt, password), 256) = pass_hash THEN
            -- Password matches
            RETURN 1;
        ELSE
            -- Password does not match
            RETURN 0;
        END IF;
    END IF;
END;

