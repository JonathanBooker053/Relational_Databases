create
    definer = jbooker@localhost procedure ShowLeaderboard()
BEGIN
    SELECT u.Username, Score FROM Client c Join Users u ON c.UserID = u.UserID ORDER BY Score DESC;
END;

