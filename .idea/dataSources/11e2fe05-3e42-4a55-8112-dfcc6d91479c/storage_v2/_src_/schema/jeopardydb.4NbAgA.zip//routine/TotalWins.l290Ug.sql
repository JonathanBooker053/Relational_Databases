create
    definer = jbooker@localhost function TotalWins(userID_ int) returns int deterministic
BEGIN
    DECLARE totalWins INT;

    -- Select the total number of games won by the specified user.
    SELECT COUNT(*) INTO totalWins
    FROM Games g
    JOIN GamePlayers gp ON g.GameID = gp.GameID
    JOIN Client c ON gp.UserID = c.UserID
    WHERE g.Status = 'Complete' AND c.UserID = userID_ AND c.Score = (SELECT MAX(Score) FROM Client WHERE UserID = userID_);

    RETURN totalWins;
END;

