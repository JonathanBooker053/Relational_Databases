create
    definer = jbooker@localhost function GameWinner(gameID int) returns int deterministic
BEGIN
    DECLARE winnerID INT;

    -- Select the user with the highest score in the specified game.
    SELECT c.UserID INTO winnerID
    FROM Client c
    JOIN GamePlayers gp ON c.UserID = gp.UserID
    WHERE gp.GameID = gameID AND c.Score = (SELECT MAX(Score) FROM Client c JOIN GamePlayers gp ON c.UserID = gp.UserID WHERE gp.GameID = gameID);

    RETURN winnerID;
END;

