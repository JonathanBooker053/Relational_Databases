create
    definer = jbooker@localhost procedure ShowPlayers()
BEGIN
    SELECT u.Username FROM Client c JOIN Users u ON c.UserID = u.UserID;
END;

