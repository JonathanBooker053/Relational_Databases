create definer = jbooker@localhost trigger AfterGameUpdate
    before update
    on Games
    for each row
BEGIN
    IF NEW.Status = 'Complete' AND OLD.Status <> 'Complete' THEN
        -- Temporary table to store scores for all players in the game
        CREATE TEMPORARY TABLE IF NOT EXISTS TempGameScores (
            GamePlayerID INT,
            Score INT
        );

        -- Insert scores into the temporary table
        INSERT INTO TempGameScores (GamePlayerID, Score)
        SELECT
            a.GamePlayerID,
            SUM(CASE WHEN a.IsCorrect = 1 THEN q.Value_ ELSE -q.Value_ END) AS TotalScore
        FROM Answer a
        JOIN GameQuestions gq ON a.GameQuestionID = gq.GameQuestionID
        JOIN Questions q ON gq.QuestionID = q.QuestionID
        WHERE gq.GameID = NEW.GameID
        GROUP BY a.GamePlayerID;

        -- Find the player with the highest score
        SET @MaxScorePlayerID := (
            SELECT GamePlayerID FROM TempGameScores
            ORDER BY Score DESC LIMIT 1
        );

        -- Update the score for the player with the highest score
        UPDATE Client c
        INNER JOIN GamePlayers gp ON c.UserID = gp.UserID
        SET c.Score = c.Score + (
            SELECT Score FROM TempGameScores WHERE GamePlayerID = @MaxScorePlayerID
        )
        WHERE gp.GamePlayerID = @MaxScorePlayerID;

        -- Drop the temporary table
        DROP TEMPORARY TABLE IF EXISTS TempGameScores;
    END IF;
END;

