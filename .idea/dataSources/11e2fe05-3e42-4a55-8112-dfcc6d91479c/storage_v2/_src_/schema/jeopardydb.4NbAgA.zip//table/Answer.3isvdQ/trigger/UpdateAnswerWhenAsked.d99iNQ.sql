create definer = jbooker@localhost trigger UpdateAnswerWhenAsked
    after insert
    on Answer
    for each row
BEGIN
    UPDATE GameQuestions gq JOIN Answer a ON gq.GameQuestionID = a.GameQuestionID
    SET gq.HasBeenAsked = 1
    WHERE a.GameQuestionID = NEW.GameQuestionID;
END;

