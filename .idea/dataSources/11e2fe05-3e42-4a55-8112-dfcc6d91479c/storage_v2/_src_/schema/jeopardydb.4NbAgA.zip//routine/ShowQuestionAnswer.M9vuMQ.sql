create
    definer = jbooker@localhost procedure ShowQuestionAnswer(IN questionID_ int)
BEGIN
    SELECT Answer FROM Questions WHERE QuestionID = questionID_;
END;

