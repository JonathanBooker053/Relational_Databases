create
    definer = jbooker@localhost procedure SetGameAdmin(IN gameID_ int, IN adminUserID int)
BEGIN
    UPDATE Games
    SET Admin = adminUserID
    WHERE GameID = gameID_;
END;

