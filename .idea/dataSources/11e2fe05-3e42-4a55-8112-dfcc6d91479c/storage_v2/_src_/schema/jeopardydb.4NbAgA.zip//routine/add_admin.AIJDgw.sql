create
    definer = jbooker@localhost procedure add_admin(IN UserID_ varchar(255))
BEGIN
    -- Check if the user is already an admin
    IF NOT EXISTS (SELECT * FROM Admin WHERE UserID = UserID_) THEN
        INSERT INTO Admin (UserID)
        VALUES (UserID_);
    END IF;
END;

